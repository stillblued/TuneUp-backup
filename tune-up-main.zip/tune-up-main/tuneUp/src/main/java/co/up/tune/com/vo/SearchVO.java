package co.up.tune.com.vo;

import lombok.Data;

@Data
public class SearchVO {
	String keyword; //검색 키워드
	String search; //입력한 값
}
