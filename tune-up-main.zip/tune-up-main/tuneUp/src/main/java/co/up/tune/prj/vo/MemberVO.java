package co.up.tune.prj.vo;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberVO {
	 int empNo;		//사번
	 int postNo;	//게시글 번호
	 String nm;		//이름
	 
	 String id; //아이디
	 String dept; //부서
}
