package co.up.tune.com.vo;

public class ChatroomVO {
	 int chatRoomNo;
	 String empNo;
	 String nm;
}
