package co.up.tune.com.vo;

import java.sql.Timestamp;

public class EmailReceiverVO {
	 String receiverEmail;	//받는사람 이메일
	 Timestamp dttm;	//수신일시
	 int sendNo;	//발송번호
	 String senderEmail;	//보낸사람 이메일
}
