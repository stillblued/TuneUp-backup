package co.up.tune.emp.attdUp.web;




import org.springframework.web.bind.annotation.RestController;



@RestController
public class AttdUpAjaxController {
	
	/*
	 * @Autowired AttdUpService dao;
	 * 
	 * 
	 * @PostMapping("/attdUpOk") public String attdUpOk(AttdUpVO vo,Model model) {
	 * model.addAttribute("attdUpOk",dao.attdUpOk(vo)); return "redirect:/attdList";
	 * }
	 */
	
}