package co.up.tune.com.vo;

import java.sql.Timestamp;

public class MessageVO {
	 int messageNo;
	 String sender;
	 String receiver;
	 String cntn;
	 Timestamp dttm;
	 int chatRoomNo;
}	
