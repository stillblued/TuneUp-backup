package co.up.tune.prj.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DemoTodoVO {
	int no;
	String cntn;
	String empNo;
}
