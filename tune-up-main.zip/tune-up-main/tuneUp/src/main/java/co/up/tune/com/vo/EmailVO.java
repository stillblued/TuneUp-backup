package co.up.tune.com.vo;

import java.util.Date;

public class EmailVO {
	 int sendNo;	//발송번호
	 String senderEmail;	//보낸사람 이메일
	 String ttl;	//제목
	 String cntn;	//내용
	 Date dttm;		//발송일시
	 String fNm;	//파일이름
	 String fPath;	//파일위치
}
